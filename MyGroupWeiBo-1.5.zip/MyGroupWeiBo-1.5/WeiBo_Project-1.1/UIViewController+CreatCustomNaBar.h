//
//  UIViewController+CreatCustomNaBar.h
//  WeiBo_Project
//
//  Created by xzx on 13-12-9.
//  Copyright (c) 2013年 Ibokan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (CreatCustomNaBar)

-(void)creatBackNavigationBarWithTitle:(NSString *)title sign:(int)sign;
@end
