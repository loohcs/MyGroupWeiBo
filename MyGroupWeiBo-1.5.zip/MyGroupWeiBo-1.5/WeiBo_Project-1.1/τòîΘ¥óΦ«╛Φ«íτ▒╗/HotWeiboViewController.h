//
//  HotWeiboViewController.h
//  SinaTwitterDemo
//
//  Created by 1014 on 13-11-26.
//  Copyright (c) 2013年 xzx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HotWeiboViewController : UIViewController
-(IBAction)reMen:(id)sender;
@end
