//
//  SendWeiboViewController.h
//  WeiBo_Project
//
//  Created by 1007 on 13-11-28.
//  Copyright (c) 2013年 Ibokan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SendWeiboViewController : UIViewController

@end
