//
//  GetIPToGeo.h
//  WeiBo_Project
//
//  Created by 1007 on 13-12-13.
//  Copyright (c) 2013年 Ibokan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GetIPToGeo : NSObject

@property (nonatomic, strong)NSString *presentIP;

- (void)getPreseentIp;

@end
