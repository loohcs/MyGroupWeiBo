//
//  CustomTabbarController.h
//  SinaTwitterDemo
//
//  Created by xzx on 13-11-21.
//  Copyright (c) 2013年 xzx. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CustomTabbarController : UITabBarController
{
    NSArray *title;
}

@property (nonatomic, strong) UIImageView *imageView;


@end
