//
//  TQRichTextImageRun.h
//  TQRichTextViewDemo
//
//  Created by fuqiang on 13-9-21.
//  Copyright (c) 2013年 fuqiang. All rights reserved.
//

#import "TQRichTextBaseRun.h"

@interface TQRichTextImageRun : TQRichTextBaseRun

@end
