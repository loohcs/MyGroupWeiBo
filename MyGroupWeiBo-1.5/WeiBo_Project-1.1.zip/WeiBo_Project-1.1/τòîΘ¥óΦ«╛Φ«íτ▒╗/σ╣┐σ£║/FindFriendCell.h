//
//  FindFriendCell.h
//  WeiBo_Project
//
//  Created by xzx on 13-12-10.
//  Copyright (c) 2013年 Ibokan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FindFriendCell : UITableViewCell
@property (nonatomic,retain)UIImageView *headImage;
@property (nonatomic,retain)UIImageView *sexImage;
@property (nonatomic,retain)UILabel *nameLable;
@property (nonatomic,retain)UILabel *descriptionLabel;
@property (nonatomic,retain)UILabel *distance;
@end
