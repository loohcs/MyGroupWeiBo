//
//  WeiboLinkViewController.m
//  WeiBo_Project
//
//  Created by 1007 on 13-12-18.
//  Copyright (c) 2013年 Ibokan. All rights reserved.
//

#import "WeiboLinkViewController.h"

@interface WeiboLinkViewController ()

@end

@implementation WeiboLinkViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
