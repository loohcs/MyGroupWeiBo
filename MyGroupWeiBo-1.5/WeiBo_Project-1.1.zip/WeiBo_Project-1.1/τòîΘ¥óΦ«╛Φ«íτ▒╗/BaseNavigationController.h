//
//  BaseNavigationController.h
//  SinaWeiBo
//
//  Created by xzx on 13-12-16.
//  Copyright (c) 2013年 xzx. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface BaseNavigationController : UINavigationController
@property (nonatomic,retain)UILabel *titleLabel;
@property (nonatomic,retain)UIButton *backButton;
@end
