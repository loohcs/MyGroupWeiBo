//
//  ClosedidViewController.h
//  SinaTwitterDemo
//
//  Created by 1014 on 13-11-27.
//  Copyright (c) 2013年 xzx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ClosedidViewController : UIViewController
-(IBAction)registered:(id)sender;
-(IBAction)addtion:(id)sender;
@end
