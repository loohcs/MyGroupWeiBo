//
//  DeleteImageINBundle.h
//  WeiBo_Project
//
//  Created by 1007 on 13-12-18.
//  Copyright (c) 2013年 Ibokan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DeleteImageINBundle : NSObject

+ (void)getImageAttribute;

@end
